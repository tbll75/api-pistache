<?php 

namespace App\Controller;

class AccueilController{

	public function index(){

		echo "<h1>La vie est belle avec Pistache !</h1>";
		echo "<p>Du coup on part sur un gros blabla qui sert à rien ? Non j'ai la flemme. Merci!<p>";

	}

}

 ?>